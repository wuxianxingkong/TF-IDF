package com.xingkong.hive;

/**
 * Created by cuiguangfan on 16-10-25.
 */
public class YdbOutputCommitter {
}
