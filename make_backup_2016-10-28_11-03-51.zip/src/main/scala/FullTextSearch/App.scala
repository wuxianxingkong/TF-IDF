package FullTextSearch

import org.apache.spark.sql.SparkSession

/**
 * @author ${user.name}
 */
object App {
  

  def main(args : Array[String]): Unit = {
    val sparkSession = SparkSession
      .builder().master("local")
      .appName("Spark SQL basic example")
      .getOrCreate()       //.config("spark.some.config.option", "some-value")
    val df=sparkSession.read.format("FullTextSearch.newdatasource").load("source1/")
    df.createOrReplaceTempView("users")
    df.printSchema()
    sparkSession.sql("select name from users").explain(true)
    sparkSession.sql("select name from users").show()

  }

}
